using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema; 
using System.Collections.Generic;
namespace Prop.API.Models
{
public class address{
         [Key]
        public int id { get; set; }
        public string address1 { get; set; }
        public string address2 { get; set; }
        public string city { get; set; }
        public string country { get; set; }
        public string county { get; set; }
        public string district { get; set; }
        public string state { get; set; }
        public string zip { get; set; }
        public string zipPlus4 { get; set; }
    
}

public class physical{
     [Key]
     public int id { get; set; }
    public string yearBuilt { get; set; }
}

public class financial{
     [Key]
      public int id { get; set; }
    public decimal yearBuilt { get; set; }
     public decimal listPrice { get; set; }
     public decimal monthlyRent { get; set; }
}

public class properties{
     public int id { get; set; }
     public address address { get; set; }
     public physical physical { get; set; }
     public financial financial { get; set; }
    


}

  }


