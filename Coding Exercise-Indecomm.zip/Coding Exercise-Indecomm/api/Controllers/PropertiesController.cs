﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Prop.API.Models;
using Prop.API.Data;

namespace Coding.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PropertiesController : ControllerBase
    {    
        private readonly ILogger<PropertiesController> _logger;
        private readonly IPropRepository _proprepo;

        public PropertiesController(ILogger<PropertiesController> logger,IPropRepository IPropRepository)
        {
            _logger = logger;
            _proprepo=IPropRepository;
        }
       
[HttpGet("GetAllAddress")]
 public async Task<IActionResult> GetAllAddress()
{
  var Groups =await _proprepo.GetAddress();
 return Ok(Groups);
 }


 [HttpPost("SaveProperties")]
 public async Task<IActionResult> SaveProperties( [FromBody] properties properties )
        {
            try{
            var createuser =await _proprepo.SaveProperties(properties);
            return StatusCode(201);
            }
            catch(Exception ex)
            {
                return StatusCode(500);
            }
          
        }
 
 }
}
