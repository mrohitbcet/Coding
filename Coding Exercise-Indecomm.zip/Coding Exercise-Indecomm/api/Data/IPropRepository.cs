using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Prop.API.Models;
using System.Collections.Generic; 
public interface IPropRepository
    {
        Task<bool> SaveProperties(properties properties);
        Task<IEnumerable<address>> GetAddress();

    }