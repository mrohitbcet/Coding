using Prop.API.Models;
using Microsoft.EntityFrameworkCore;

namespace Prop.API.Data
{
    public class DataContext:DbContext
    {
        public DataContext(DbContextOptions<DataContext> options):base(options)
        { }
        public DbSet<address> addresss{get;set;}
        public DbSet <physical> physicals {get;set;}
        public DbSet <financial> financials {get;set;}
        
    }
}