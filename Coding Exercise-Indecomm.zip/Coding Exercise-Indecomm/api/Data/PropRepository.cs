using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Prop.API.Models;
using System.Collections.Generic;
using Prop.API.Data;
using Microsoft.EntityFrameworkCore;

public class PropRepository : IPropRepository
{
    private readonly DataContext _context;
    public PropRepository(DataContext context)
    {
       this._context = context; 
    }
    public async Task<bool> SaveProperties(properties properties)
        {
            if(properties.id>0)
            {
                if(await _context.addresss.AnyAsync(xx=>xx.id==properties.id))
                {
                _context.Entry(properties.address).State = EntityState.Modified;
                await _context.SaveChangesAsync();
                }
                else
                {
                 var address = await _context.addresss.AddAsync(properties.address);
                  await _context.SaveChangesAsync();
                }



                if(await _context.physicals.AnyAsync(xx=>xx.id==properties.id))
                {
                _context.Entry(properties.physical).State = EntityState.Modified;
                await _context.SaveChangesAsync();
                }
                else
                {
                 var physical = await _context.physicals.AddAsync(properties.physical);
                  await _context.SaveChangesAsync();
                }



                if(await _context.financials.AnyAsync(xx=>xx.id==properties.id))
                {
                _context.Entry(properties.financial).State = EntityState.Modified;
                await _context.SaveChangesAsync();
                }
                else
                {
                 var financial = await _context.financials.AddAsync(properties.financial);
                  await _context.SaveChangesAsync();
                }
            }
         return true;
        }

    public async Task<IEnumerable<address>> GetAddress()
        {
         
           var address=await (_context.addresss.ToListAsync());
            return address;

        }
   
}