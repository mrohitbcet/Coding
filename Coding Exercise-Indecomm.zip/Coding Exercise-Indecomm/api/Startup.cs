using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Prop.API.Data;

namespace Coding
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //services.AddDbContext<DataContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultDatabaseConnection")));
                services.AddDbContext<DataContext>(options => options.UseSqlServer("Server=103.235.106.33;Database=Demodb;User ID=bansaruli;password=Rmuri@333"));
                services.AddCors();
                services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
            services.AddScoped<IPropRepository,PropRepository>();
            services.AddControllers();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
       
           
    
 
          app.UseHttpsRedirection();
          //app.UseCors(x=>x.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
          app.UseCors(builder=>
          builder.WithOrigins("http://localhost:5000").AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
          app.UseRouting();

            app.UseAuthentication();
          
          app.UseEndpoints(endpoints =>
            {
               endpoints.MapControllers();
         });
           
        }
    }
}
