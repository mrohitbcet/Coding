export class properties{
    id:number;
    address ?: address;
    physical?: physical;
    financial?:financial;
}

export class address{
    address1 :string;
	address2 : string;
	city:string;
	country : string;
	county : string;
	district : string;
	state : string;
    zip : string;
    zipPlus4: string;
}

export class physical{
    yearBuilt:string;
}

export class financial{
    listPrice:number;
    monthlyRent:number;
}