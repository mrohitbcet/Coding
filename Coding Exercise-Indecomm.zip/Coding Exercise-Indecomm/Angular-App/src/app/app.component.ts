import { Component } from '@angular/core';
import { properties, address, physical, financial } from './model/prop'
import { HttpClient } from '@angular/common/http';
import {PropertiesService} from './properties.service'


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular-App';
  properties:properties[];
  propModel:properties={
 id:0,
 address:null,
 physical:null,
 financial:null
}
  constructor(private http: HttpClient,private PropertiesService:PropertiesService) {
    
    
  }
  ngOnInit() {
    this.Getproperties();
  }

  Getproperties()
 {
  this.PropertiesService.Getproperties().subscribe((PopList:properties[])=>{
   this.properties=PopList;
   console.log(this.properties);
   
  });
 }

 SaveData(id:number,address:address,physical:physical, financial:financial)
 {
   var result= this.properties.filter(
    data => data.id ==id);
    console.log(result);
    this.propModel.id=id;
    this.propModel.address=address;
    this.propModel.physical=physical;
    this.propModel.financial=financial;
    console.log(this.propModel);
    this.PropertiesService.Saveproperties(this.propModel).subscribe(() => {
      alert('Properties Saved succssfully!')
      
     }, error => {
          alert(error)
        
    });
 }
}
