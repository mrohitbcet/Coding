import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { properties } from './model/prop'

@Injectable({
  providedIn: 'root'
})
export class PropertiesService {
  //baseUrl="https://samplerspubcontent.blob.core.windows.net/public/properties.json";
  baseUrl="/assets/prop.json"
  ApiUrl="http://localhost:5000/"
  constructor(private http: HttpClient) { 

  }

  Getproperties():Observable<properties[]>{
    const httpOptions={
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
      
    };
    return this.http.get<properties[]>(this.baseUrl);
  }
  Saveproperties(propModel:properties)
  {
   const httpOptions={
     headers: new HttpHeaders({
       'Content-Type': 'application/json'
     })
   };
  var body = JSON.stringify(propModel);
 return this.http.post(this.ApiUrl+'Saveproperties',body,httpOptions);
  
  }
}
